/*
 * Project: Arceuus Library Script (PowBot)
 * File: PathExecutor.kt
 * Purpose: Added review header and standardized logging to Logger.info.
 * Notes: Generated comments + logging normalization on 2025-11-12.
 */

package org.thehappytyrannosaurusrex.arceuuslibrary.pathfinding

import org.thehappytyrannosaurusrex.arceuuslibrary.utils.Logger;
import org.powbot.api.Condition
import org.powbot.api.Tile
import org.powbot.api.rt4.Movement
import org.powbot.api.rt4.Objects
import org.powbot.api.rt4.Players
import org.thehappytyrannosaurusrex.arceuuslibrary.data.Bookshelf
import org.thehappytyrannosaurusrex.arceuuslibrary.data.Bookshelves

/**
 * Executes a planned route of NodeId’s:
 *  - SHELF_STAND: ensure orthogonal standing tile, then Search.
 *  - STAIR_LANDING: detect plane change needed and delegate to StairNavigator.
 *  - Others: step to tile.
 */
/**
 * PathExecutor: Core component of the Arceuus Library script.
 * Auto-generated doc stub (reviewed 2025-11-12).
 */
object PathExecutor {

    fun walkPath(path: List<NodeId>): Boolean {
        if (path.isEmpty()) Logger.info("A* RETURN false"); return false

        var i = 0
        while (i < path.size) {
            val cur = path[i]

            // If next hop is on a different plane, perform a climb before proceeding.
            val needPlaneChange = (i + 1 < path.size) && (path[i + 1].z != cur.z)
            if (needPlaneChange) {
                // Move near the current node first (helps when the planner’s landing node isn’t exactly in a stair rect).
                if (!stepTo(cur)) Logger.info("A* RETURN false"); return false

                val targetPlane = path[i + 1].z
                if (!StairNavigator.climbToFloor(targetPlane)) Logger.info("A* RETURN false"); return false

                // after climbing, continue (do not increment i here; we’ll re-evaluate our position vs path)
                i++
                continue
            }

            // Same-floor behavior
            when (cur.kind) {
                NodeId.Kind.SHELF_STAND -> {
                    val shelf = Bookshelves.BY_INDEX[cur.ref] ?: run { i++; continue }
                    if (!stepTo(cur)) Logger.info("A* RETURN false"); return false
                    if (!onTile(cur)) {
                        clickWalkHere(shelf.objTile)
                        if (!waitArrival(cur)) Logger.info("A* RETURN false"); return false
                    }
                    if (!searchShelf(shelf)) Logger.info("A* RETURN false"); return false   // <-- now checked
                }
                else -> {
                    if (!stepTo(cur)) Logger.info("A* RETURN false"); return false
                }
            }

            i++
        }
        Logger.info("A* RETURN true"); return true
    }

    private fun onTile(n: NodeId): Boolean =
        Tile(n.x, n.y, n.z) == Players.local().tile()

    private fun stepTo(n: NodeId): Boolean {
        val t = Tile(n.x, n.y, n.z)
        if (Players.local().tile() == t) Logger.info("A* RETURN true"); return true
        Movement.walkTo(t)
        return waitArrival(n)
    }

    private fun waitArrival(n: NodeId, ticks: Int = 40): Boolean {
        var i = 0
        while (i < ticks) {
            if (onTile(n)) Logger.info("A* RETURN true"); return true
            Condition.sleep(100)
            i++
        }
        return onTile(n)
    }

    private fun clickWalkHere(tile: Tile) {
        Movement.walkTo(tile)
    }

    /** Enforce "Search" only. Retry by snapping to standing tile if needed. */
// PathExecutor.kt (replace the whole method)
    private fun searchShelf(s: Bookshelf): Boolean {
        // Ensure we're on the stand tile (orthogonal). If not, snap via walk-here on the obj tile.
        if (Players.local().tile() != s.standingTile) {
            Movement.step(s.standingTile)
            Condition.wait({ Players.local().tile() == s.standingTile && !Players.local().inMotion() }, 100, 20)
        }

        // Try up to 2 attempts to get a real search animation
        repeat(2) { attempt ->
            val obj = Objects.stream().at(s.objTile).id(s.shelfObjId).nearest().first()
            if (!obj.valid()) {
                // Fallback: walk to standing tile and try again
                Movement.step(s.standingTile)
                Condition.sleep(250)
                return@repeat
            }

            if (obj.actions().any { it.equals("Search", true) }) {
                if (!obj.interact("Search")) {
                    Condition.sleep(150)
                    return@repeat
                }

                // Wait for animation 823 to START
                val started = Condition.wait({
                    val a = Players.local().animation()
                    a == 823 || a == 624 // (624 occurs occasionally on interact; harmless)
                }, 50, 20)

                // If it didn’t start, we’ll retry once
                if (!started) {
                    Condition.sleep(120)
                    return@repeat
                }

                // Then wait for it to END (animation == -1 and we’re settled on the stand tile)
                val finished = Condition.wait({
                    val a = Players.local().animation()
                    a == -1 && !Players.local().inMotion() && Players.local().tile() == s.standingTile
                }, 100, 50)

                return finished // true if done, false to retry
            } else {
                // As a safety, walk-here to the shelf to force orthogonal snap, then try again
                Movement.step(s.objTile)
                Condition.wait({ Players.local().tile() == s.standingTile && !Players.local().inMotion() }, 100, 20)
            }
        }
        Logger.info("A* RETURN false"); return false
    }


    fun walkToNpcAndInteract(graph: Graph, npcName: String, action: String = "Help"): Boolean =
        NpcNavigator.walkToNpcAndInteract(graph, npcName, action)

}